<div class="container-fluid-expand">
            <div class='row'>
                <div class="col">
                    <center>
                    <h1>Modes de paiement</h1> <hr>
                    </center>
                </div> 
            </div> 
        </div>
<div class="container-fluid-expand">
            <center>
            <div class="row"> 
                <div class="col-12 col-lg-4 m-auto "> 
                            
                            <div class="card m-4 border-primary shadow-lg">


                                <h5 class="card-title">Moyens de Paiement</h5>
                                        <p class="card-text" > <img src="img/Attention.jpg" height="20" width="25" alt="Attention"> <style> </style>
                                            Les paiements se font uniquement auprès de notre responsable financier ISSA SAMAGASSI.</p>
                                        <center><p class="card-text"> PAR </p></center>
                                        <p class="card-text"> <img src="img/OM.PNG" alt="Logo OM"> Orange Monney +225 0798696853 </p>
                                        <p class="card-text"> <img src="img/MO.JPG" alt="Logo MOMO"> MTN Moble Monney +225 0554510210 </p>
                                        <p class="card-text"> <img src="img/SIB.PNG" alt="Virement"> N° de compte (0707 86955782829 34) </p>
                            </div>
                </div> 

                <div class="col-12 col-lg-4 m-auto ">
                        <div class="card m-4 border-primary shadow-lg">
                            <h5 class="card-title">Méthodes de Paiement</h5>
                                <center>
                                     <p class="card-text"> <img src="img/OM.PNG" alt="Logo OM"> <img src="img/MO.JPG" alt="Logo MOMO"> </p>
                                </center>
                                <p class="card-text">                          </p>
                                <p class="card-text">Informez le responsable financier avant et après votre paiement, suite à sa confirmation retirez votre reçu neccessaire au retrait de votre tenue.</p>   
                                <center>
                                     <p class="card-text"> <img src="img/SIB.PNG" alt="Virement"> </p>
                                </center>
                                <p class="card-text">Informez le responsable financier avant le Virement ensuite envoyez le reçu du virement et retirez votre reçu neccessaire au retrait de votre tenue.</p>  
                                <p class="card-text"> Contactez le <img src="img/Flêche.PNG" height="30" width="35" alt="Flêche"> <a href="https://api.whatsapp.com/send?phone=2250798696853" class="btn ">
                                            
                                                <span class="fa fa-whatsapp icon"></span>
                                            +225 0798696853
                                        </a>
                                        <span class="fa fa-phone"></span> <a href="tel:<?php echo $site_phone ?>"><?php echo $site_phone ?></a>
                                </p>
                                <p class="card-text">                                                                                         </p>
                                <p class="card-text">                                                                                         </p>
                               
                                
                        </div> 
                </div>  
                
                <div class="col-12 col-lg-4 m-auto ">
                        <div class="card m-4 border-primary shadow-lg">
                            <h5 class="card-title">Reçu de Paiement</h5>
                                <center>
                                     <p class="card-text"> <img src="img/Reçu.PNG" alt="reçu"> </p>
                                </center>
                                <p class="card-text">Conserver bien votre reçu car il est neccéssaire pour le retrait de votre commande.</p>
                                <p class="card-text">                                                                  </p>
                                <p class="card-text">                                                                  </p>
                                <p class="card-text">                                                                  </p>
                                <p class="card-text">                                                                  </p>
                        </div>
                </div>
            </div>
            </center>
        
         </div>






                
            </div>
      </div>

  
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>