
      <div class="container-fluid-expand">
            <div class='row'>
                <div class="col">
                    <center>
                    <h1>Comment commander votre KIT étudiant ?</h1> <hr>
                    </center>
                </div> 
            </div> 
        </div>
        <div class="container-fluid-expand">
            <div class="row"> 
                <div class="col-12 col-lg-4 "> 
                    <center>
                    <button type="button" class="btn btn-primary  ">
                        Etape 1: Telecharger le document de mensuration</button>
                    
                            
                            <div class="card m-4 border-primary shadow-lg">
                                <h5 class="card-title">Document de mensuration</h5> <hr>
                                <img class="card-img-top" src="img/mesure.PNG" alt="Document de mensuration">
                                <div class="card-body">
                                    <p class="card-text"><a class="nav-link" href="doc/mensuration.DOCX"><span class="btn  btn-primary">Telecharger</span></a></p>

                                    
                                        <p class="card-text">
                                               Après télechargement rendez-vous chez le tailleur le plus proche pour la prise de vos mesures en suivant les champs de ce document à remplire soigneusement</p>
                                       
                                       <p></p>
                                       <p></p>
                                       <p></p>
                                       <p>
                                           
                                       </p>
                                       
                                       
                                       
                                               <!-- SE CONNECTER AVANT DE TELECHARGER -->
                                       
                                               <!-- <a href="doc/mensuration.DOCX" class="btn btn-primary">Télécharger</a> -->
                                        <!-- <a href="?q=document" class="btn btn-primary">Télécharger</a> -->
                                        <!-- <div class="nav-item dropdown dropleft">
                                                <?php if ($us_id <= 0 and $pme_id <= 0){ //user not connected ?>
                                                    <a href="doc/mensuration.DOCX"  data-toggle="dropdown">
                                                        <span class="btn  btn-primary">Telecharger</span>
                                                    </a>
                                            <div class="dropdown-menu">
                                                    <span class="dropdown-item-text">Connexion</span>
                                                    <a class="dropdown-item" href="#" data-toggle="modal" data-target="#modalConnexion">
                                                        <button type="button" class="btn btn-dark btn-sm btn-block">Connexion client </button>
                                                    </a>
                                                                            
                                                    <span class="dropdown-item-text">Inscription</span>
                                                    <a class="dropdown-item" href="#" data-toggle="modal" data-target="#modalInscription">
                                                        <button type="button" class="btn btn-dark btn-sm btn-block">Inscription client </button>
                                                    </a>
                                                                            
                                                </div>
                                            <?php }else if ($pme_id > 0){ ?>
                                                <a class="nav-link" href="?q=pme"><span class="btn  btn-primary">Telecharger</span></a>
                                                <?php }else{ ?>
                                                <a class="nav-link" href="doc/mensuration.DOCX"><span class="btn  btn-primary">Telecharger</span></a>
                                                <?php } ?>
                                            </div> -->
                                        



                                       
                                </div>
                            </div></center>
                </div>
            
                <div class="col-12 col-lg-4 ">
                    <center>
                    <button type="button" class="btn btn-primary ">
                        Etape2: Prise de votre mesure au près du tailleur le plus proche
                    </button>
                    
                    
                    <div class="card m-4 border-primary shadow-lg" >
                        <p class="card-text"> <img class="card-img-top" src="img/documentation.JPG" alt="Documentation">
                        <p class="card-text"> Une video sur la prise de mesure <img src="img/Flêche.PNG" height="30" width="35" alt="Flêche"><a href="https://www.youtube.com/watch?v=G1_2VrmMWfA" target="_blank" class="btn btn-primary">Documentation</a></p>
                        <p class="card-text">                                                                                         </p>
                    </div></center>


                   
                    <center>
                    <button type="button" class="btn btn-primary ">
                        Etape3: Envoyez vos mesures de confection
                    </button>
                    
                    <div class="card m-4 border-primary shadow-lg" >
                        <p class="card-text"> <img class="card-img-top" src="img/wha.PNG" alt="Conversation what">
                        <p class="card-text"><a href="https://api.whatsapp.com/send?phone=2250798696853" target="_blank" class="btn btn-primary ">
                                            
                                            <span class="fa fa-whatsapp icon"></span>
                                            Envoyez via whatsapp
                                    </a>
                        <p class="card-text">                                                                                         </p>
                    </div></center>
                </div>

                <div class="col-12 col-lg-4 ">
                     <center>
                    <button type="button" class="btn btn-primary ">
                    Etape 3: Envoyer vos messure de confection
                    </button> 
                    <div class="card m-4 border-primary shadow-lg" >
                            
                        <p class="card-text"> <img class="card-img-top" src="img/emai.PNG" alt="conversation email"> </p>
                        <p class="card-text"> <a href="mailto:vs.cloths21@yahoo.com" class="btn btn-primary">
                            <span class="fa fa-email icon"></span>
                            Envoyez via email
                            </a>
                        </p>
                        <p class ="card-text"> Contactez-nous si besoin <span class="fa fa-phone"></span> <a href="tel:<?php echo $site_phone ?>"><?php echo $site_phone ?></a></p> 
                        <p class="card-text"> Cliquez sur l'étape 4 pour voir nos modes de paiement <img src="img/red.jfif" height="30" width="35" alt="Flêche"><p></p>
                        <p class="card-text">                                                                                         </p>
                                      
                    </div></center>  
                </div>
            </div>
        </div>


       
         <a href="?q=paiement" class="btn btn-primary btn-lg btn-block">Etape 4: Voir les modes de paiement et contacter notre responsable financier pour payer votre avance.
                    </a>
            
  
    