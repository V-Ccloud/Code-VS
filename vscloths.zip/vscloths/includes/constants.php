<?php
// this is all constants of the website

$site_name = "VS-CLOTHS";

$site_adresse = " VS-CLOTHS, Yamoussoukro, Côte d'Ivoire";

$site_email = "vs.cloths21@yahoo.com";

$site_phone = "+2250554510210";

$site_facebook = "https://www.facebook.com/VSCLOTHS/?ref=pages_you_manage";

$site_instagram = "https://www.instagram.com/vs.cloths/";

$site_twitter = "https://twitter.com/ClothsVs";

$site_whatsapp = "+2250798696853";

$site_linkedin = "https://www.linkedin.com/company/vs-cloths/?viewAsMember=true";

$devise = "DH";

$types_produit = array('Kit Complet', 'Kit Moyen', 'Kit Simple');

?>