<?php
//----------toutes les contantes du site----------
$acronyme_site = 'VS';

$nom_site = 'VS-CLOTHS';

$domaine = 'localhost/vscloths';

$mail_site = 'vs.cloths@yahoo.com';

$lien_fichier = '../';

$devise = "fcfa";
?>